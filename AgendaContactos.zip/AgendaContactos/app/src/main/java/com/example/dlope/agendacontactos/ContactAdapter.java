package com.example.dlope.agendacontactos;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

/**
 * Created by dlope on 07/12/2017.
 */

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ViewHolder> {

    private List<Contact> listContacts;
    private Context context;
    //private Cursor mCursor;

    public ContactAdapter(Context context, List<Contact> lista) {
        //this.mCursor = cursor;
        this.listContacts = lista;
        this.context = context;
    }

    public void swapList(List<Contact> nuevaLista) {

        listContacts = nuevaLista;
        notifyDataSetChanged();

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.contact_list_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
//        if(!mCursor.moveToPosition(position)) return;
//        String name = mCursor.getString(mCursor.getColumnIndex(DBcontract.DBentry.COLUMN_CONTACT_NAME));
//        final int number = mCursor.getInt(mCursor.getColumnIndex(DBcontract.DBentry.COLUMN_CONTACT_NUMBER));
//        long id =mCursor.getLong(mCursor.getColumnIndex(DBcontract.DBentry._ID));
        final Contact contact = listContacts.get(position);
        holder.contactNumber.setText(String.valueOf(contact.getNumero()));
        holder.contactName.setText(contact.getNombre());
        holder.contactInitial.setText(contact.getNombre().substring(0,1));
        holder.itemView.setTag(contact.getNombre());//stores the id of the element in the list without showing it
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+String.valueOf(contact.getNumero())));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listContacts.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView contactName;
        private TextView contactNumber;
        private TextView contactInitial;

        public ViewHolder(View itemView) {
            super(itemView);
            contactName = (TextView) itemView.findViewById(R.id.tv_item_name);
            contactNumber = (TextView) itemView.findViewById(R.id.tv_item_number);
            contactInitial = (TextView) itemView.findViewById(R.id.tv_item_initial);
        }

        }
}
