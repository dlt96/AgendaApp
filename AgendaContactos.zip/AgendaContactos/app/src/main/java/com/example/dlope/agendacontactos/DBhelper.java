package com.example.dlope.agendacontactos;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by dlope on 07/12/2017.
 */

public class DBhelper extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION=1;

    public DBhelper(Context context, String database_name){
        super(context,database_name,null,DATABASE_VERSION);
    }

    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE "+ DBcontract.DBentry.TABLE_NAME + " ("+
                    DBcontract.DBentry._ID + " INTEGER PRIMARY KEY," +
                    DBcontract.DBentry.COLUMN_CONTACT_NAME + " TEXT UNIQUE,"+
                    DBcontract.DBentry.COLUMN_CONTACT_NUMBER + " INTEGER"+
                    " );";

    private static final String SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS " + DBcontract.DBentry.TABLE_NAME;

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
}
