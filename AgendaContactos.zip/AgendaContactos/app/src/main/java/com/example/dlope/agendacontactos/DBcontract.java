package com.example.dlope.agendacontactos;

import android.provider.BaseColumns;

/**
 * Created by dlope on 07/12/2017.
 */

public final class DBcontract {
    public static abstract class DBentry implements BaseColumns{
        public static final String TABLE_NAME ="contactos";
        public static final String COLUMN_CONTACT_NAME ="nombreContacto";
        public static final String COLUMN_CONTACT_NUMBER ="numeroContacto";

    }
}
