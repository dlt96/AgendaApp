package com.example.dlope.agendacontactos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by dlope on 07/12/2017.
 */

public class Agenda {
    private DBhelper dbHelper;
    private SQLiteDatabase db;

    public Agenda(Context cont){
        this.dbHelper = new DBhelper(cont, "db");
    }

    public void insertaContacto(String nombre, String telefono){
        if(nombre.length()==0 || telefono.length()==0)return;
        ContentValues values = new ContentValues();
        values.put(DBcontract.DBentry.COLUMN_CONTACT_NAME,nombre);
        values.put(DBcontract.DBentry.COLUMN_CONTACT_NUMBER,telefono);
        db = dbHelper.getWritableDatabase();
        db.insertWithOnConflict(DBcontract.DBentry.TABLE_NAME,null,values,SQLiteDatabase.CONFLICT_REPLACE);
        db.close();
    }

    public boolean borraContacto(String nombre){
        String where = DBcontract.DBentry.COLUMN_CONTACT_NAME + "=?";
        String [] whereArgs ={nombre};
        db = dbHelper.getWritableDatabase();
        int delete = db.delete(DBcontract.DBentry.TABLE_NAME,where,whereArgs);
        db.close();
        if(delete >0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean borraContacto(long id) {
        db = dbHelper.getWritableDatabase();
        int delete = db.delete(DBcontract.DBentry.TABLE_NAME,
                DBcontract.DBentry._ID + "=" + id, null);
        db.close();
        if(delete >0) {
            return true;
        } else {
            return false;
        }
    }

    public void editaContacto(String nombre, String telefono,String nombreNuevo, String telefonoNuevo){
        ContentValues values = new ContentValues();

        if(!nombre.equals(nombreNuevo)){
            values.put(DBcontract.DBentry.COLUMN_CONTACT_NAME, nombreNuevo);
        }
        if(!telefono.equals(telefonoNuevo)){
            values.put(DBcontract.DBentry.COLUMN_CONTACT_NUMBER, telefonoNuevo);
        }
        String where = DBcontract.DBentry.COLUMN_CONTACT_NAME + " = ?";
        String[] whereArgs = { nombre };
        db = dbHelper.getWritableDatabase();
        db.update(DBcontract.DBentry.TABLE_NAME, values, where, whereArgs);
        db.close();
    }

    public Cursor getAllContacts(){
        db = dbHelper.getReadableDatabase();
        return db.query(DBcontract.DBentry.TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                DBcontract.DBentry.COLUMN_CONTACT_NAME
        );


    }

    public Cursor getContact(String s){
        db = dbHelper.getReadableDatabase();
        return db.rawQuery("SELECT * FROM "+ DBcontract.DBentry.TABLE_NAME +" WHERE "+ DBcontract.DBentry.COLUMN_CONTACT_NAME + " LIKE ? ;",
                new String[] {"%"+s+"%"});


    }

}
