package com.example.dlope.agendacontactos;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

public class AddContact extends AppCompatActivity {

    static String AGENDA = "AGENDA";
    private Agenda agenda;
    TextInputLayout nameTextInput;
    TextInputLayout numberTextInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);

        agenda = (Agenda) SingletonMap.getInstance().get(AGENDA);
        if(agenda == null){
            agenda = new Agenda(getApplicationContext());
            SingletonMap.getInstance().put(AGENDA,agenda);
        }
        nameTextInput = findViewById(R.id.textInputLayoutNombre);
        numberTextInput = findViewById(R.id.textInputLayoutNumero);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    public void addContact(View view){
        if(agenda != null){
            String name = nameTextInput.getEditText().getText().toString();
            String number = numberTextInput.getEditText().getText().toString();

            boolean notEmptyName = !name.isEmpty();
            boolean notEmptyNumber = !number.isEmpty();
            if(!notEmptyName){
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                alertDialogBuilder.setTitle(R.string.emptyName);
                alertDialogBuilder
                        .setMessage(R.string.emptyNameAction)
                        .setCancelable(false)
                        .setPositiveButton(R.string.introduce, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        })
                        .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                AddContact.this.finish();
                            }
                        });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }

            if(!notEmptyNumber){
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                alertDialogBuilder.setTitle(R.string.emptyNumber);
                alertDialogBuilder
                        .setMessage(R.string.emptyNumberAction)
                        .setCancelable(false)
                        .setPositiveButton(R.string.introduce, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        })
                        .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                AddContact.this.finish();
                            }
                        });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }

            if(notEmptyName && notEmptyNumber){
                agenda.insertaContacto(
                        name,
                        number);
                Snackbar.make(findViewById(R.id.addContact), R.string.addedContact, Snackbar.LENGTH_LONG).show();
                nameTextInput.getEditText().setText("");
                numberTextInput.getEditText().setText("");
                hideKeyboardFrom(this,view);//cerramos teclado
            }

        }


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if(id== android.R.id.home){
            this.finish();
        }
        return super.onOptionsItemSelected(item);
    }

    public static void hideKeyboardFrom(Context context, View view) {//cerrar teclado
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Activity.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}
