package com.example.dlope.agendacontactos;

import java.util.HashMap;

/**
 * Created by dlope on 07/12/2017.
 */

public class SingletonMap extends HashMap <String,Object> {

    private static class SingletonHolder{
        private static final SingletonMap ourInstance = new SingletonMap();

    }

    public static SingletonMap getInstance(){
        return SingletonHolder.ourInstance;
    }

    private SingletonMap(){

    }
}
