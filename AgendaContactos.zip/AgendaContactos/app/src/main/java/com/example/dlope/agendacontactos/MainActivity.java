package com.example.dlope.agendacontactos;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ContactAdapter adapter;

    private List<Contact> contactList;
    static String AGENDA = "AGENDA";
    private Agenda agenda;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        agenda = (Agenda) SingletonMap.getInstance().get(AGENDA);
        if(agenda == null){
            agenda = new Agenda(getApplicationContext());
            SingletonMap.getInstance().put(AGENDA, agenda);
        }

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        contactList = loadRecyclerViewData();

        adapter = new ContactAdapter(this,contactList);

        recyclerView.setAdapter(adapter);


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);//add contact
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), AddContact.class);
                startActivity(intent);
            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {//swipe to delete
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                String nombre = (String) viewHolder.itemView.getTag();
                agenda.borraContacto(nombre);
                contactList = loadRecyclerViewData();
                adapter.swapList(contactList);

               Snackbar.make(findViewById(R.id.recyclerView), R.string.deletedContact, Snackbar.LENGTH_LONG).show();
            }
        }).attachToRecyclerView(recyclerView);

    }

    public ArrayList<Contact> loadRecyclerViewData(){//find all
        cursor = agenda.getAllContacts();
        ArrayList<Contact> mArrayList = new ArrayList<Contact>();
        for(cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
            // The Cursor is now set to the right position
            mArrayList.add(new Contact(cursor.getString(
                    cursor.getColumnIndex(DBcontract.DBentry.COLUMN_CONTACT_NAME)),
                    cursor.getInt(cursor.getColumnIndex(DBcontract.DBentry.COLUMN_CONTACT_NUMBER))));
        }
        return mArrayList;
    }

    public ArrayList<Contact> loadRecyclerViewData(Cursor c){//find
        cursor = c;
        ArrayList<Contact> mArrayList = new ArrayList<Contact>();
        for(cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
            // The Cursor is now set to the right position
            mArrayList.add(new Contact(cursor.getString(
                    cursor.getColumnIndex(DBcontract.DBentry.COLUMN_CONTACT_NAME)),
                    cursor.getInt(cursor.getColumnIndex(DBcontract.DBentry.COLUMN_CONTACT_NUMBER))));
        }
        return mArrayList;
    }


    @Override
    protected void onResume(){
        super.onResume();
        contactList = loadRecyclerViewData();
        adapter.swapList(contactList);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        SearchView searchView = null;
        getMenuInflater().inflate(R.menu.main_menu,menu);
        MenuItem menuItem = menu.findItem(R.id.action_search);
        searchView = (SearchView) menuItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                contactList.clear();
                contactList.addAll(loadRecyclerViewData(agenda.getContact(s)));
                adapter.swapList(loadRecyclerViewData(agenda.getContact(s)));
                if(contactList.size()==0 && !s.isEmpty()){
                    Toast toast = Toast.makeText(getApplicationContext(),R.string.contactNotFound,Toast.LENGTH_SHORT);
                    toast.show();
                }
                return true;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                contactList.clear();
                contactList.addAll(loadRecyclerViewData(agenda.getContact(s)));
                adapter.swapList(loadRecyclerViewData(agenda.getContact(s)));
                if(contactList.size()==0 && !s.isEmpty()){
                    Toast toast = Toast.makeText(getApplicationContext(),R.string.contactNotFound,Toast.LENGTH_SHORT);
                    toast.show();
                }
                return true;
            }
        });
        return true;
    }




}
